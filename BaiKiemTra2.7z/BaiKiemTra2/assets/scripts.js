console.log(document.getElementById('NoiDung'))
const MangDuLieu = []
var dateNow = new Date()

//Scripts   Bài 1 
const GuiDuLieu = ()=>{
    i=1
    if(sessionStorage.getItem(1) === null)
    {
        sessionStorage.setItem(i,document.getElementById('NoiDung').value +`*`+`(`+dateNow.getHours()+`:`+dateNow.getMinutes()+`:`+dateNow.getSeconds()+`)`+dateNow.getDate()+`-`+(dateNow.getMonth()+1)+`-`+dateNow.getFullYear())
    }
    else{
        do{
            MangDuLieu.push({key:i,value:sessionStorage.getItem(i)})
            i++
        }while(sessionStorage.getItem(i)!==null)
        sessionStorage.setItem(i,document.getElementById('NoiDung').value +`*`+`(`+dateNow.getHours()+`:`+dateNow.getMinutes()+`:`+dateNow.getSeconds()+`)`+dateNow.getDate()+`-`+(dateNow.getMonth()+1)+`-`+dateNow.getFullYear())
    }
}
//Scripts   Bài 2

window.onload = function GetDuLieu(){
    var dulieu = ``
    i=1
    if(sessionStorage.getItem(1) === null)
    {

    }
    else{
        do{
            MangDuLieu.push({key:i,value:sessionStorage.getItem(i)})
            i++
        }while(sessionStorage.getItem(i)!==null)
        //console.log(MangDuLieu)
    }
    MangDuLieu.map(x=>{
        dulieu += `
        <li>Key : `+x.key+` - Giá trị : `+ x.value.split('*')[0] +` - Thời gian : `+x.value.split('*')[1]+`</li>
        `
    })
    //console.log(dulieu)
    var tag_id = document.getElementById('DanhSach')
    tag_id.innerHTML = dulieu;
}

